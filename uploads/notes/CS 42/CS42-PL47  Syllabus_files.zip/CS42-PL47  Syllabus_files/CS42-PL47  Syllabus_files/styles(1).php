/**************************************
 * THEME NAME: standardblue
 *
 * Files included in this sheet:
 *
 *   standardblue/gradients.css
 **************************************/

/***** standardblue/gradients.css start *****/

/**
  *  Adds all the nice finish to the standard theme
  *
  */

th.header,
td.header,
div.header {     
    background-image:url(gradient.jpg);     
    background-position:top;    
    background-repeat:repeat-x;     
}

.navbar {
    background-image:url(gradient.jpg);     
    background-position:top;    
    background-repeat:repeat-x;     
}

/***** standardblue/gradients.css end *****/

