//declaration of stacks
	var stack = new Array();
	var stk1 = new Array();
	var stk2 = new Array();
	var stk3 = new Array();
	var stk4 = new Array();
	var stk5 = new Array();
	var stk6 = new Array();
	var stk7 = new Array();
    
    var tlstk = new Array();
    var trstk= new Array();
	var flag=1;
	//to assign properties to the card 
	function Card(index, value, type,color,image,close) {
		this.value = value;
		this.type = type;
		this.color = color;
		this.image = image;
		this.close = close;
		this.index = index
		//document.write(this.image);
	}

	// to create a array of all the cards and allocate the properties for it
	var k=1,i=1,c,j;
	var cards = new Array(52);
	for(j=1;j<=13;j++,i++) { cards[i]=new Card(j,i,"heart","red","heart"+j+".png",1); }
	for(j=1;j<=13;j++,i++) { cards[i]=new Card(j,i,"spade","black","spade"+j+".png",1); }
	for(j=1;j<=13;j++,i++) { cards[i]=new Card(j,i,"diamond","red","diamond"+j+".png",1); }
	for(j=1;j<=13;j++,i++) { cards[i]=new Card(j,i,"club","black","club"+j+".png",1); }

	//stack functions
		function Stack()
		{
		 this.stac=new Array();
		 this.pop=function(){
		  return this.stac.pop();
		 }
		 this.push=function(item){
		  this.stac.push(item);
		 }
		 this.GetCount=function(){
		   return this.stac.length;
		  }
		}	
// fuction to shuffle cards
     function shuffle() {
		for (c = 1; c <= 1000; c++)
		{
			var random1=Math.floor(Math.random() * 52 +1);
			var random2=Math.floor(Math.random() * 52 +1);
			var temp = cards[random2];
			cards[random2] = cards[random1];
			cards[random1] = temp;
		}
	}
 // insert cards to all stacks
function game(){

	shuffle();		
	var count = 1;
	var c;
	var i;
	for( c = 1; c <= 7; c++) {
	
	if(c==1)
	{
		for( i = 0; i < c; i++) {
			stk1.push(cards[count]);
			count++;
		}
	}

	if(c==2)
	{
		for( i = 0; i < c; i++) {
			stk2.push(cards[count]);
			count++;
		}
	}

	if(c==3)
	{
		for( i = 0; i < c; i++) {
			stk3.push(cards[count]);
			count++;
		}
	}


	if(c==4)
	{
		for( i = 0; i < c; i++) {
			stk4.push(cards[count]);
			count++;
		}
	}

	if(c==5)
	{
		for( i = 0; i < c; i++) {
			stk5.push(cards[count]);
			count++;
		}
	}

	if(c==6)
	{
		for( i = 0; i < c; i++) {
			stk6.push(cards[count]);
			count++;
		}
	}

	if(c==7)
	{
		for( i = 0; i < c; i++) {
			stk7.push(cards[count]);
			count++;
		}
	}
			
		
	}
//push cards in top stack
for( i = count; i <=52; i++){
	tlstk.push(cards[count])
	count++;
} 
	
//call dispay function
	displayImgaes();
/*
	var img = document.createElement("img");
    img.setAttribute("src", "images/close.png");
    img.setAttribute("id","closeCard");
    document.getElementById("tl_left").appendChild(img);

	var img = document.createElement("img");
	img.setAttribute("src", "images/close.png");
	img.setAttribute("id","openCard");
	document.getElementById("tl_right").appendChild(img);
*/

}


// fuction to dispay and move cards
function displayImgaes(){
var count = 1;
var c;
var i;
for( c = 1; c <= 7; c++) {
	if(c==1) {
		    for(var i = 0; i < stk1.length ; i++) { 

		    var img = document.createElement("img");
		    if(i==0)
		 	    img.setAttribute("style", "margin-top:0px"); 
		    else
		    	img.setAttribute("style", "margin-top:-120px"); 
		       	var last=stk1.length-1;
		        stk1[last].close=false;
		        
		    if(stk1[i].close==false)
		            img.setAttribute("src", "images/"+stk1[i].image);
		    else
		        img.setAttribute("src", "images/close.png");
		        img.setAttribute("draggable", "true"); 
		        img.setAttribute("id", stk1[i].value); 
		        img.setAttribute("id", stk1[i].color);
		        img.setAttribute("id", stk1[i].index);
		        img.setAttribute("ondragstart", "drag(event,this)"); 
		        document.getElementById("stk1").appendChild(img);
		        }
			}	

	if(c==2) {
		    for(var i = 0; i < stk2.length ; i++) { 

		    var img = document.createElement("img");
		    if(i==0)
		 	    img.setAttribute("style", "margin-top:0px"); 
		    else
		    	img.setAttribute("style", "margin-top:-120px"); 
		       	var last=stk2.length-1;
		        stk2[last].close=false;
		        
		    if(stk2[i].close==false)
		            img.setAttribute("src", "images/"+stk2[i].image);
		    else
		        img.setAttribute("src", "images/close.png");
		        img.setAttribute("draggable", "true"); 
		        img.setAttribute("id", stk2[i].value); 
		        img.setAttribute("id", stk2[i].color);
		         img.setAttribute("id", stk2[i].index);
		        img.setAttribute("ondragstart", "drag(event,this)"); 
		        document.getElementById("stk2").appendChild(img);
		        }
			}	

	if(c==3) {
		    for(var i = 0; i < stk3.length ; i++) { 

		    var img = document.createElement("img");
		    if(i==0)
		 	    img.setAttribute("style", "margin-top:0px"); 
		    else
		    	img.setAttribute("style", "margin-top:-120px"); 
		       	var last=stk3.length-1;
		        stk3[last].close=false;
		        
		    if(stk3[i].close==false)
		            img.setAttribute("src", "images/"+stk3[i].image);
		    else
		        img.setAttribute("src", "images/close.png");
		        img.setAttribute("draggable", "true"); 
		        img.setAttribute("id", stk3[i].value); 
		        img.setAttribute("id", stk3[i].color); 
		        img.setAttribute("id", stk3[i].index);
		        img.setAttribute("ondragstart", "drag(event,this)"); 
		        document.getElementById("stk3").appendChild(img);
		        }
			}	


	if(c==4) {
		    for(var i = 0; i < stk4.length ; i++) { 

		    var img = document.createElement("img");
		    if(i==0)
		 	    img.setAttribute("style", "margin-top:0px"); 
		    else
		    	img.setAttribute("style", "margin-top:-120px"); 
		       	var last=stk4.length-1;
		        stk4[last].close=false;
		        
		    if(stk4[i].close==false)
		            img.setAttribute("src", "images/"+stk4[i].image);
		    else
		        img.setAttribute("src", "images/close.png");
		        img.setAttribute("draggable", "true"); 
		        img.setAttribute("id", stk4[i].value); 
		        img.setAttribute("id", stk4[i].color); 
		        img.setAttribute("id", stk4[i].index);
		        img.setAttribute("ondragstart", "drag(event,this)"); 
		        document.getElementById("stk4").appendChild(img);
		        }
			}	

	if(c==5) {
		    for(var i = 0; i < stk5.length ; i++) { 

		    var img = document.createElement("img");
		    if(i==0)
		 	    img.setAttribute("style", "margin-top:0px"); 
		    else
		    	img.setAttribute("style", "margin-top:-120px"); 
		       	var last=stk5.length-1;
		        stk5[last].close=false;
		        
		    if(stk5[i].close==false)
		            img.setAttribute("src", "images/"+stk5[i].image);
		    else
		        img.setAttribute("src", "images/close.png");
		        img.setAttribute("draggable", "true"); 
		        img.setAttribute("id", stk5[i].value); 
		        img.setAttribute("id", stk5[i].color); 
		         img.setAttribute("id", stk5[i].index);
		        img.setAttribute("ondragstart", "drag(event,this)"); 
		        document.getElementById("stk5").appendChild(img);
		        }
			}	

	if(c==6) {
	    for(var i = 0; i < stk6.length ; i++) { 

	    var img = document.createElement("img");
	    if(i==0)
	 	    img.setAttribute("style", "margin-top:0px"); 
	    else
	    	img.setAttribute("style", "margin-top:-120px"); 
	       	var last=stk6.length-1;
	        stk6[last].close=false;
	        
	    if(stk6[i].close==false)
	            img.setAttribute("src", "images/"+stk6[i].image);
	    else
	        img.setAttribute("src", "images/close.png");
	        img.setAttribute("draggable", "true"); 
	        img.setAttribute("id", stk6[i].value); 
	        img.setAttribute("id", stk6[i].color); 
	         img.setAttribute("id", stk6[i].index);
	        img.setAttribute("ondragstart", "drag(event,this)"); 
	        document.getElementById("stk6").appendChild(img);
	        }
		}	

	

	if(c==7) {
	    for(var i = 0; i < stk7.length ; i++) { 

	    var img = document.createElement("img");
	    if(i==0)
	 	    img.setAttribute("style", "margin-top:0px"); 
	    else
	    	img.setAttribute("style", "margin-top:-120px"); 
	       	var last=stk7.length-1;
	        stk7[last].close=false;
	        
	    if(stk7[i].close==false)
	            img.setAttribute("src", "images/"+stk7[i].image);
	    else
	        img.setAttribute("src", "images/close.png");
	        img.setAttribute("draggable", "true"); 
	        img.setAttribute("id", stk7[i].value); 
	        img.setAttribute("id", stk7[i].color); 
	         img.setAttribute("id", stk7[i].index);
	        img.setAttribute("ondragstart", "drag(event,this)"); 
	        document.getElementById("stk7").appendChild(img);
	        }
		}	


var last=trstk.length;
if(last!=0)
    {
	    console.log(last);
	    last=last-1;
	    document.getElementById("openCard").setAttribute("src", "images/" + trstk[last].image);
	}
else
    {
    	document.getElementById("openCard").setAttribute("src", "");
    }

}



}



// Function to ChangeCard

function changeCard(){
    
    if (flag==0) {
        document.getElementById("openCard").setAttribute("src", "images/close1.png");//back side
        document.getElementById("closeCard").setAttribute("src", "images/close.png");//blank
        flag=1;
    }
    else{
        if (tlstk.length>0){
            var tmp = tlstk.pop();
            trstk.push(tmp);
            document.getElementById("openCard").setAttribute("src", "images/" + tmp.image);
            document.getElementById("openCard").setAttribute("ondragstart", "drag(event,this)"); 

        }
        if(tlstk.length==0){
            document.getElementById("openCard").setAttribute("src", "images/close.png");
            document.getElementById("openCard").setAttribute("ondragstart", ""); 
            trstk.length;
            while(trstk.length>0){
            console.log(trstk.length);
            tlstk[tlstk.length]=trstk[trstk.length-1];
            trstk.pop();
            flag=0;
            }
        }
    }
}





function allowDrop(ev) {
    ev.preventDefault();
}

function drag(event,e) {
    console.log(e);
    event.dataTransfer.setData("card_id", event.target.id);
    event.dataTransfer.setData("div1", e.parentNode.id);
    console.log(e.parentNode.id);
}

function drop(event,e) {
    div2=e.id;
    event.preventDefault();
     data = event.dataTransfer.getData("card_id");
     div1 = event.dataTransfer.getData("div1");
     //destCard = document.getElementById(div2)
    var stack1=get_stack_form_div(div1)
    var stack2=get_stack_form_div(div2)

    destCard = stack2[ (stack2.length - 1)]
    SourceCard = document.getElementById(data)

    //console.log(SourceCard.getAttribute("color"))
    Destcolor = stack2[stack2.length -1].color
    Sourcecolor =stack1[stack1.length -1].color

    DestIndex = stack2[stack2.length -1].index
    SourceIndex =stack1[stack1.length -1].index

    console.log(div1+" "+div2)
    console.log(stack1+" "+stack2)
    console.log(data);




if (Destcolor != Sourcecolor  && (DestIndex-SourceIndex == 1) ){
    if(stack1.length > 0){
    var temp=stack1.pop();
     }
    stack2.push(temp);
    }
    //document.getElementById(div2).appendChild(document.getElementById(data));
    clear();
    displayImgaes();
}





function get_stack_form_div(div){
	if(div=="stk1")
	    return stk1;
	if(div=="stk2")
	    return stk2;
	if(div=="stk3")
	    return stk3;
	if(div=="stk4")
	    return stk4;
	if(div=="stk5")
	    return stk5;
	if(div=="stk6")
	    return stk6;
	if(div=="stk7")
	    return stk7;
	if(div=="tl_right")
	    return trstk ;
} 


function clear(){
 for (var i = 1; i <= 7; i++)
    {
    var div="stk"+i; 
    document.getElementById(div).innerHTML="";
    }

}